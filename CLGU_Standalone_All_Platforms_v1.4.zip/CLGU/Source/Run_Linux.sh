#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
fail() { printf '\n%s\n' "$1" >&2; exit 1; }
command -v python3 >/dev/null || fail "Install Python 3.10 or newer first."
python3 -c 'import sys; assert sys.version_info >= (3,10)' || fail "Python 3.10 or newer is required."
python3 -c 'import tkinter' 2>/dev/null || fail "Tkinter is missing. Debian/Ubuntu: sudo apt install python3-tk python3-venv"
if [[ ! -x .venv/bin/python ]]; then
    python3 -m venv .venv || fail "Cannot create virtual environment. Debian/Ubuntu: sudo apt install python3-venv"
fi
if [[ ! -f .venv/requirements-installed.txt ]] || ! cmp -s requirements.txt .venv/requirements-installed.txt; then
    .venv/bin/python -m pip install -r requirements.txt || fail "Dependency install failed. Check internet access, then run this launcher again."
    cp requirements.txt .venv/requirements-installed.txt
fi
exec .venv/bin/python ip_geolocator.py
