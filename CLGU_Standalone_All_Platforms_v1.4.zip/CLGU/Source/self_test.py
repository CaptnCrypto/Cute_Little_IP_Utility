"""Local packaging smoke test; no network requests or user document access."""
import csv
import json
from pathlib import Path
import tempfile
import tkinter as tk
from zipfile import ZipFile


def run(report_path):
    from ip_geolocator import GeoLocatorApp
    from geo_core import read_document, extract_ips, export_csv, OnlineLocator, VirusTotalClient
    from openpyxl import Workbook
    from pypdf import PdfWriter
    import certifi
    import xlrd
    checks = []
    root = tk.Tk()
    app = GeoLocatorApp(root)
    try:
        root.update()
        app.paste.insert("1.0", "8.8.8.8 8.8.8.8 192.168.1.1 2606:4700:4700::1111")
        app.add_paste()
        assert len(app.rows) == 3
        checks.append("GUI startup, pasted text, deduplication, IPv4/IPv6")
        assert app.rows["192.168.1.1"]["Status"] == "Skipped"
        checks.append("Non-public addresses skipped locally")
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            for ext, member, content in [
                ("docx", "word/document.xml", '<w:document xmlns:w="urn:w"><w:p><w:r><w:t>8.8.8.8</w:t></w:r></w:p></w:document>'),
                ("odt", "content.xml", '<root><p>8.8.8.8</p></root>')]:
                path = folder / ("sample." + ext)
                with ZipFile(path, "w") as archive:
                    archive.writestr(member, content)
                assert extract_ips(read_document(path)) == ["8.8.8.8"]
            checks.append("Bundled DOCX/ODT extraction and XML parser")
            wb = Workbook()
            wb.active["A1"] = "8.8.8.8"
            path = folder / "sheet.xlsx"
            wb.save(path)
            wb.close()
            assert extract_ips(read_document(path)) == ["8.8.8.8"]
            checks.append("Bundled XLSX reader")
            path = folder / "text.rtf"
            path.write_text(r"{\rtf1\ansi 8.8.8.8}")
            assert extract_ips(read_document(path)) == ["8.8.8.8"]
            checks.append("Bundled RTF reader")
            path = folder / "blank.pdf"
            writer = PdfWriter()
            writer.add_blank_page(width=600, height=800)
            writer.write(path)
            try:
                read_document(path)
            except ValueError as exc:
                assert "OCR" in str(exc)
            else:
                raise AssertionError("Empty PDF was not flagged")
            checks.append("Bundled PDF reader and OCR-required handling")
            path = folder / "report.csv"
            export_csv(path, app.rows.values())
            with path.open(encoding="utf-8-sig", newline="") as stream:
                rows = list(csv.DictReader(stream))
            assert len(rows) == 3 and "VT Malicious" in rows[0]
            checks.append("CSV export includes all IP rows and VirusTotal columns")
        assert Path(certifi.where()).is_file()
        OnlineLocator()
        client = VirusTotalClient("a" * 64)
        client.close()
        checks.append("Bundled HTTPS certificate bundle and API clients initialize")
        Path(report_path).write_text(json.dumps({"result": "PASS", "checks": checks}, indent=2), encoding="utf-8")
    finally:
        app.shutdown()
