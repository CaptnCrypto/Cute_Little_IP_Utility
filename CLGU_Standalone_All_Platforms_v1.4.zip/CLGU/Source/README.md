# Cute Little Geolocation Utility (CLGU) — Windows, Linux and macOS

Import one or more documents, extract unique IPv4/IPv6 addresses, look up their locations, optionally retrieve VirusTotal IP reputation reports, and export all results to a CSV. Internet access is required for online lookups. Python, pip, an API key for geolocation, and local geolocation databases are not required to run the packaged apps.

## Start the application

Extract the entire ZIP first.

- **Windows 10/11, 64-bit:** open `Windows/CLGU.exe`. It contains its own Python/Tk runtime and dependencies. It expands to a temporary folder, runs without an installation wizard or administrator rights, and normally removes that temporary folder after closing. No registry, startup or file-association changes are made.
- **Linux, x86-64 desktop:** open `Linux/CLGU`. If executable permission was lost while extracting, run `chmod +x Linux/CLGU` and then `./Linux/CLGU`. It bundles Python/Tcl/Tk and the required Python packages. A glibc-based graphical Linux desktop with X11 libraries or XWayland is required. This is not an ARM or Alpine/musl binary. A writable executable temporary directory is needed for its bundled runtime; filesystems mounted with `noexec` may require an approved alternate temporary directory via `TMPDIR`.

The Windows file is a portable self-extracting application, not a permanent installer. Both programs are unsigned. The Linux executable was launched and smoke-tested here; the Windows executable was built and its embedded payload verified, but was not run on a native Windows machine. Do a Windows smoke test with `sample_ips.txt` before operational use.

## The normal workflow

1. Click **Add documents** and select one or several files. You can also paste text and click **Add pasted text**. Importing is local and sends no requests.
2. Review the extracted IPs. Each unique valid IP has one row, an occurrence count and its source filename(s). Invalid IPs are ignored. Private and special-use IPs are retained as skipped rows and are never queried online.
3. Click **Geolocate / retry unfinished**. The app requests country, region/state, city, postal code, ISP, organization, ASN, latitude/longitude and timezone when the provider supplies them. No geolocation API key is needed.
4. Optionally enter your **VirusTotal API key** in the masked field. Click **VirusTotal: selected / all**. If rows are selected, it checks those; otherwise it checks all unchecked public IPs. Hold Ctrl to select multiple rows. The key is held for this application session and is not saved in the CSV or in a settings file. Use **Clear key** to remove it from the field.
5. Click **Export ALL rows to CSV**, choose a destination, and open the result in Excel or LibreOffice Calc. You can geolocate only, check VirusTotal only, or run both in either order.

**Export before closing.** The workspace is in memory until exported. The CSV is a report, not a resumable project. Closing the app clears the workspace. Imported files are read without changing them. The same path is imported once per workspace; clear the workspace to reimport a changed file.

## Results and controls

- **Stop** interrupts a wait immediately and stops after an active document/request finishes. Network requests have a 15-second timeout. Completed results are retained for export.
- **Retry unfinished** retries pending/error geolocation rows; successful results remain. VirusTotal similarly keeps completed checks. Clear and reimport to refresh every result from the services.
- Filter the table by any field. Filtering does not restrict CSV export. VirusTotal uses selected rows or all eligible rows, including rows hidden by a filter when none are selected.
- Click column headings to sort. Scroll horizontally for additional fields. Double-click a row for the complete record. Select rows and press Ctrl+C to copy their IPs.
- The geolocation **Status** and **VT Status** fields are separate. `Pending`/`Not checked` means that lookup has not completed. `Error` retains the reason. `Not found` means no VirusTotal report was available. `No analysis data` means the report supplied no analysis statistics. Empty detection fields do not mean zero detections.

CSV columns include geolocation fields, occurrences, source paths, provider, lookup UTC, any error, and VirusTotal status, malicious/suspicious/harmless/undetected/timeout counts, reputation, last-analysis UTC, lookup UTC, report URL and any VT error. Missing provider fields remain blank. Timestamps describe the lookup or existing VT analysis, not the activity time in your documents. CSV is UTF-8 with a BOM for Excel; text that could execute as a spreadsheet formula is prefixed with an apostrophe. Exports use an atomic replacement to protect an existing CSV if writing fails.

## Supported documents

| Source | Formats |
| --- | --- |
| Word | `.docx`: paragraphs, tables, headers, footers, footnotes, endnotes and comments |
| LibreOffice | `.odt`, `.ods`, `.odp` |
| Notepad / logs / text | `.txt`, `.csv`, `.tsv`, `.log`, `.md`, `.json`, `.xml`, `.yaml`, `.yml`, `.ini`, `.conf`, extensionless text |
| Spreadsheets | `.xlsx`, `.xls`; saved cell/formula text, not rendered number formatting |
| Presentations | `.pptx`: slides and speaker notes |
| PDF | `.pdf` containing selectable text |
| Other | `.rtf`, `.html`, `.htm`; raw `.eml` text |

Scanned PDFs and images need OCR first. Password-protected Office files, images, embedded objects/attachments, `.docm`, `.pages`, old `.ppt` and arbitrary binary formats are not supported. Legacy `.doc` should be resaved as `.docx`, `.odt` or `.txt`; Linux can optionally use `antiword` if already installed. Raw EML scanning does not decode encoded message bodies or attachments: save/decode them separately. The input limit is 64 MiB per file; expanded Office containers are limited to 128 MiB. Macros are not executed.

IPv4 with a port, bracketed IPv6 with a port, and written IPs in CIDR notation are recognized. CIDR ranges are not expanded. IPv6 is normalized and its zone suffix removed. Defanged IPs such as `8[.]8[.]8[.]8` and IPv4 with leading zeroes are not accepted. Occurrence counts describe extracted text, which may include comments, headers or hidden cells.

## Online services

**Geolocation:** HTTPS requests to `https://ipwho.is/{IP}`. The provider currently documents a free endpoint without an API key and a limit of 1,000 requests/day per outbound client IP. The app spaces requests by at least 1.1 seconds and stops a batch on quota/rate-limit responses. Other users of the same outbound IP may share the provider limit. Documentation: https://ipwhois.io/documentation and terms: https://ipwhois.io/terms

**VirusTotal:** read-only HTTPS `GET /api/v3/ip_addresses/{IP}` requests using your key in the `x-apikey` header. It retrieves existing IP reports, never uploads a document and never submits a scan/rescan. The app waits at least 16 seconds between VT attempts within a session (about four requests/minute) and stops on an authentication or quota error. A 100-IP batch takes roughly 26 minutes. Current public limits include four requests/minute and 500/day; your licensed plan governs allowed use and quota. Use a key licensed for your intended personal or organizational use; the public API has use restrictions. The conservative app interval also applies to premium keys.

Get your own key: https://www.virustotal.com/gui/my-apikey
API docs: https://docs.virustotal.com/reference/ip-info
API plans/terms: https://docs.virustotal.com/reference/public-vs-premium-api

Limits and terms can change. The app does not bypass them. Restarting does not reset a service quota. No live VirusTotal check was made during development because no user API key was supplied; integration behavior was tested with response fixtures.

Only requested IPs and routine HTTP headers are sent to the selected service. VirusTotal also receives its API key. Providers see your outbound network IP. Documents, filenames and surrounding text are not uploaded. TLS certificates are verified, redirects are refused, and configured system proxy settings may apply. There is no application telemetry or persistent lookup cache.

## Interpret results carefully

Geolocation estimates an IP network's location. It does not identify a subscriber, prove a person's location or establish where an IP was used historically. VPNs, hosting, mobile networks and carrier NAT can affect results. VirusTotal counts reflect providers' existing reputation classifications; zero malicious detections is not proof that an IP is safe. Existing reports may be old. Preserve original evidence separately.

## Troubleshooting

- If a document has no IPs, confirm that its text can be selected. Try the included `sample_ips.txt`, export the original document as UTF-8 text, or OCR a scanned PDF.
- If a CSV is locked, close it in Excel/Calc or choose another destination.
- For HTTPS errors, check internet access, the system clock and organization-approved proxy/certificate settings. TLS verification is not disabled.
- On a quota/authentication error, export partial results, check your API access and retry later.
- If Linux will not launch, check executable permission, x86-64 architecture, a graphical display, X11/XWayland libraries and permission to execute extracted runtime files in the temporary directory.
- If Windows fails to start, it should show a startup message. Retain that message for troubleshooting. Managed systems may apply software approval policies to unsigned or temporary applications.

## Source and verification

`Source/` contains the Python application, tests and build scripts for review or modification. Running the source requires Python 3.10+ and `requirements.txt`; those prerequisites are not required for the packaged executables. Source launchers and normal PyInstaller build scripts are included. `portable_windows.nsi` documents the portable Windows wrapper, whose runtime provenance is recorded in `BUILD_INFO.json`.

See `VALIDATION.md` for completed checks and limits. Third-party licenses are included in `LICENSES/` and within the bundled Windows runtime. Developer smoke-test command: `CLGU --self-test /absolute/path/report.json` (on Windows, use the EXE name). It opens/closes the GUI, tests local document readers and CSV export, and makes no network requests.

## CLGU appearance (version 1.3)

The toxic-green title **Cute Little Geolocation Utility (CLGU)** is centered at the top. A smaller centered line underneath reads **by: CaptnCrypto & ChatGPT**, in red with a small red heart on each side. The FDLE logo has been removed. The approved green monster remains the application, window/taskbar and Windows executable icon. If an older pinned shortcut shows a cached icon, unpin it and pin the new running CLGU.exe.

## macOS standalone apps (package 1.4)

The `macOS/Apple_Silicon/CLGU.app` and `macOS/Intel/CLGU.app` bundles contain their own matching CPython 3.12.15 runtime, native Tcl/Tk 9 GUI libraries, HTTPS certificates, document readers and the same application source/assets used by the Windows/Linux versions. Choose the bundle matching your Mac, extract the full ZIP on macOS and open CLGU.app, or copy that entire .app to Applications first. No Python, Homebrew or package installation is required on the destination Mac. The green monster is included as the Finder/Dock icon. The centered green title and red byline/hearts are unchanged.

The supplied native files declare minimum macOS versions of 11.0 for Apple Silicon and 10.15 for Intel. This indicates the build target, not a completed native compatibility test. The bundles are unsigned and have not been notarized by Apple. macOS may require local software approval, and managed devices may block them. No security settings are disabled or altered by the application. Native launch, Gatekeeper behavior and the Dock appearance still need a Mac smoke test.

The Windows and Linux executables are unchanged from the previous 1.3 package. No live authenticated VirusTotal request was made during this packaging step. All service limits, API-key handling and CSV behavior described above apply on Mac as well.

Developer note: `Source/build_macos_bundles.py` assembles both bundles from separately downloaded, SHA-256-verified architecture-specific runtimes and reviewed pure-Python dependencies. It verifies native architecture and preserves native-file bytes. The ZIP preserves executable permissions and relative symlinks. Signing/notarization and native smoke testing require access to macOS and appropriate Apple credentials. Runtime provenance and native-dependency validation are in `macOS/BUILD_VALIDATION.json` and `BUILD_INFO.json`.
