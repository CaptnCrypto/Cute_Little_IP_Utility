#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
python3 -m venv .build-venv
.build-venv/bin/python -m pip install -r requirements.txt pyinstaller
.build-venv/bin/python -m PyInstaller --noconfirm --clean --onefile --windowed --name CLGU --icon assets/clgu_monster.ico --add-data "assets:assets" --collect-all certifi --collect-all striprtf --collect-all defusedxml --collect-all pypdf --collect-all openpyxl --collect-all xlrd ip_geolocator.py
printf '\nBuilt: dist/CLGU\nBuild on the oldest Linux distribution you need to support; architectures must match.\n'
