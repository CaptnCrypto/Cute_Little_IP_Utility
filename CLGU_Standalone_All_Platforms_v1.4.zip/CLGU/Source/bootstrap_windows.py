"""Start the bundled desktop app and surface startup failures without a console."""
import ctypes
from pathlib import Path
import sys

try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from ip_geolocator import main
    main()
except Exception as exc:
    ctypes.windll.user32.MessageBoxW(None, "CLGU could not start.\n\n" + str(exc), "Cute Little Geolocation Utility (CLGU)", 0x10)
    raise SystemExit(1)
