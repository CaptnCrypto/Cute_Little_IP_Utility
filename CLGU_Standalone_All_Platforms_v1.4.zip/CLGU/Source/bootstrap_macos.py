"""Launch the bundled macOS application without using a system Python."""
from pathlib import Path
import subprocess
import sys

try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from ip_geolocator import main
    main()
except Exception as exc:
    script = 'on run argv\n display alert "CLGU could not start" message (item 1 of argv) as critical\nend run'
    try:
        subprocess.run(["/usr/bin/osascript", "-e", script, str(exc)], check=False)
    except OSError:
        print("CLGU could not start:", exc, file=sys.stderr)
    raise SystemExit(1)
