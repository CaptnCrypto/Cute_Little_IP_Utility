; Build a single-file portable application, with no permanent installation.
; makensis -DPAYLOAD=<bundled-python-folder> -DOUTPUT=<output.exe> portable_windows.nsi
Unicode true
!include "FileFunc.nsh"
!include "x64.nsh"
Name "Cute Little Geolocation Utility (CLGU)"
Icon "${ICON}"
OutFile "${OUTPUT}"
RequestExecutionLevel user
SilentInstall silent
AutoCloseWindow true
SetCompressor /SOLID lzma
SetCompressorDictSize 32
CRCCheck on
ManifestDPIAware true
ManifestSupportedOS all
VIProductVersion "1.3.0.0"
VIAddVersionKey /LANG=1033 "ProductName" "Cute Little Geolocation Utility (CLGU)"
VIAddVersionKey /LANG=1033 "FileDescription" "Document IP geolocation and VirusTotal report lookup"
VIAddVersionKey /LANG=1033 "FileVersion" "1.3.0"
VIAddVersionKey /LANG=1033 "LegalCopyright" "Application code 2026; bundled components retain their licenses"

Function .onInit
  ${IfNot} ${RunningX64}
    MessageBox MB_OK|MB_ICONSTOP "This application requires 64-bit Windows 10 or Windows 11."
    Abort
  ${EndIf}
FunctionEnd

Section
  InitPluginsDir
  SetOutPath "$PLUGINSDIR\IP_GeoLocator"
  File /r "${PAYLOAD}/*"
  SetOutPath "$EXEDIR"
  ${GetParameters} $0
  ClearErrors
  ExecWait '"$PLUGINSDIR\IP_GeoLocator\pythonw.exe" -I -B "$PLUGINSDIR\IP_GeoLocator\bootstrap_windows.py" $0' $1
  IfErrors launch_error
  ${If} $1 != 0
    MessageBox MB_OK|MB_ICONSTOP "CLGU exited with an error. If a startup error was shown, use that message for troubleshooting."
    SetErrorLevel $1
  ${EndIf}
  Goto done
launch_error:
  MessageBox MB_OK|MB_ICONSTOP "Could not launch the bundled application. Ensure Windows permits execution from your user TEMP folder and that there is enough free disk space."
  SetErrorLevel 1
done:
SectionEnd
