# Validation — CLGU 1.3.0

Completed 2026-10-19 on a Linux x86-64 host.

- **41 automated tests passed**, including eight GUI tests running under Xvfb.
- Core tests cover IPv4/IPv6 validation, source/occurrence counts, common document formats, Word formatting runs/tabs, LibreOffice spacing, text encodings, private/special address skipping, input limits, XML entity rejection, Unicode CSV, spreadsheet formula protection and atomic export failure handling.
- GUI tests cover importing multiple files, duplicate-path handling, lookup and retry, stopping, provider quota handling, filtered-table/full-CSV behavior, VirusTotal key validation, selected-IP checks, authentication failures and preserving geolocation/VT results in either lookup order.
- VirusTotal HTTP/response fixtures cover statistics, reputation, UTC timestamps, missing reports, missing analysis data, authentication and quota errors, HTTPS endpoints, key-in-header authentication and private-address rejection. No real user API key was supplied, so **no live authenticated VirusTotal request was made**.
- A live HTTPS geolocation request for the public DNS address 8.8.8.8 returned location/network data. This validates the provider integration, not the precision of its estimate.
- Additional DOCX, ODT and legacy XLS files generated with independent writer libraries were successfully imported.
- The **final standalone Linux executable** launched with Python environment variables removed and a restricted PATH. Its local smoke test passed GUI startup, deduplication, IPv4/IPv6, private-address handling, bundled DOCX/ODT/XLSX/RTF/PDF readers, CSV export and HTTPS-client/certificate initialization.
- The Windows executable was compiled as a portable NSIS application with a bundled x64 CPython 3.12.15 runtime. The downloaded runtime hash was checked against its release asset metadata. All **2,293 packaged files** were extracted from the EXE and matched byte-for-byte against the staged payload, including Python, Tcl/Tk, certificate data, document readers and application code.
- **The Windows executable has not been launched on a native Windows system.** Payload verification is not a Windows runtime test. Start it on Windows 10/11 x64, import sample_ips.txt, geolocate, optionally test a permitted VirusTotal key, and export CSV before operational use.
- Linux testing used an X11 virtual display on this host, not every target distribution or desktop. The executable is for x86-64 glibc Linux, with a graphical desktop/X11 libraries or XWayland. It is not an ARM or Alpine/musl build. The bundled Python/Tcl/Tk native libraries reference glibc symbols no newer than 2.17; that is a compatibility indicator, not certification of every older distribution.
- Binaries are unsigned. No claim of code signing, native Windows certification, universal document support, OCR capability or guaranteed geolocation/reputation accuracy is made.

BUILD_INFO.json records runtime provenance and executable SHA-256 hashes. Source and tests are included for review. The local executable smoke test makes no online requests and never needs a real VirusTotal key.

## Version 1.3 appearance checks

The existing workflow test suite previously passed 41 tests. This release changes the header presentation only. Visual inspection and runtime assertions verified a centered toxic-green title, the exact smaller byline by: CaptnCrypto & ChatGPT in red (#FF4141), two matching red hearts, and no FDLE logo widget. The FDLE image asset was removed from the source and bundled Windows runtime.

The final standalone Linux executable passed its local smoke test with Python environment variables removed. The Windows EXE was rebuilt, extracted and compared against all 2,302 staged files; the red styling is present and FDLE artwork is absent. The monster app/executable icon is retained. This Windows build has not been run natively here.

## macOS bundles — package 1.4

Both architecture-specific CPython archives were downloaded from the upstream release and matched their published SHA-256 digests. App manifests, launchers, executable permissions, document-reading dependencies, certificate data and Tcl/Tk resources were checked. Native Mach-O files were validated for arm64/x86-64 architecture and retained byte-for-byte; their dependent bundled library paths resolve, and other declared paths are macOS system libraries/frameworks. Main-window source and image assets match the existing GUI. The Mac app bundles were NOT executed on macOS and are NOT Apple-signed/notarized. Static checks cannot establish successful Finder startup, Gatekeeper approval, live networking, or Dock icon behavior on a Mac.
