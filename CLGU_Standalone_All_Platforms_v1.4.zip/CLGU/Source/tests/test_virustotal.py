import io
import json
from pathlib import Path
import sys
import unittest
from urllib.error import HTTPError

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from geo_core import AuthenticationError, RateLimited, ReportNotFound, VirusTotalClient


class VirusTotalTests(unittest.TestCase):
    def client(self, payload):
        client = VirusTotalClient("a" * 64)
        class Opener:
            def open(self, request, timeout):
                self.request = request
                if isinstance(payload, Exception):
                    raise payload
                return io.BytesIO(json.dumps(payload).encode())
        client.opener = Opener()
        return client

    def test_report_mapping_and_key_in_header_only(self):
        client = self.client({"data": {"id": "8.8.8.8", "attributes": {"last_analysis_stats": {"malicious": 2, "suspicious": 1, "harmless": 70, "undetected": 10}, "reputation": -5, "last_analysis_date": 1700000000}}})
        result = client.lookup("8.8.8.8")
        self.assertEqual(result["VT Malicious"], 2)
        self.assertEqual(result["VT Reputation"], -5)
        self.assertEqual(result["VT Last Analysis UTC"], "2023-11-14T22:13:20+00:00")
        request = client.opener.request
        self.assertEqual(request.full_url, "https://www.virustotal.com/api/v3/ip_addresses/8.8.8.8")
        self.assertEqual(request.get_header("X-apikey"), "a" * 64)
        self.assertIsNone(request.data)
        self.assertEqual(request.get_method(), "GET")
        client.close()
        self.assertEqual(client._api_key, "")

    def test_empty_stats_are_not_zero_detections(self):
        result = self.client({"data": {"id": "8.8.8.8", "attributes": {}}}).lookup("8.8.8.8")
        self.assertEqual(result["VT Status"], "No analysis data")
        self.assertEqual(result["VT Malicious"], "")

    def test_http_errors_and_no_secret_in_message(self):
        for code, exception in [(401, AuthenticationError), (403, AuthenticationError), (404, ReportNotFound), (429, RateLimited)]:
            client = self.client(HTTPError("https://www.virustotal.com", code, "error", {}, None))
            with self.subTest(code=code), self.assertRaises(exception) as caught:
                client.lookup("8.8.8.8")
            self.assertNotIn("a" * 64, str(caught.exception))

    def test_private_addresses_rejected(self):
        with self.assertRaisesRegex(ValueError, "Non-public"):
            self.client({}).lookup("192.168.1.1")

    def test_invalid_key_rejected(self):
        for value in ["", "short", "a\r\nx-foo:bar"]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                VirusTotalClient(value)

    def test_mismatched_ip_rejected(self):
        with self.assertRaisesRegex(ValueError, "different IP"):
            self.client({"data": {"id": "1.1.1.1", "attributes": {}}}).lookup("8.8.8.8")


if __name__ == "__main__":
    unittest.main()
