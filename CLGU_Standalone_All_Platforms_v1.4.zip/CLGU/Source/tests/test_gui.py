import csv
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import ip_geolocator as gui
from geo_core import RateLimited


@unittest.skipUnless(os.name == "nt" or os.environ.get("DISPLAY"), "GUI tests require a display")
class GUITests(unittest.TestCase):
    def setUp(self):
        self.root = gui.tk.Tk()
        self.app = gui.GeoLocatorApp(self.root)
        self.root.update()
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.addCleanup(self.app.shutdown)

    def finish(self):
        deadline = time.monotonic() + 8
        while self.app.busy and time.monotonic() < deadline:
            self.root.update()
            time.sleep(.02)
        self.root.update()
        self.assertFalse(self.app.busy)

    def add(self, text="8.8.8.8 8.8.8.8 192.168.1.1"):
        self.app.paste.insert("1.0", text)
        self.app.add_paste()

    def fake(self, error=None):
        class Locator:
            name = "Test fixture"
            def lookup(self, ip):
                if error:
                    raise error
                return {"Country": "Test country", "City": "Fixture city"}
            def close(self):
                pass
        return Locator

    def test_paste_lookup_filter_export_all_and_details(self):
        self.add()
        self.assertEqual(len(self.app.rows), 2)
        self.assertEqual(self.app.rows["8.8.8.8"]["Occurrences"], 2)
        with patch.object(gui, "OnlineLocator", self.fake()):
            self.app.start_lookup()
            self.finish()
        self.assertEqual(self.app.rows["8.8.8.8"]["Status"], "Success")
        self.app.search.set("Fixture city")
        self.assertEqual(len(self.app.tree.get_children()), 1)
        self.app.tree.selection_set("8.8.8.8")
        self.app.show_details()
        self.root.update()
        path = str(Path(self.temp.name) / "all.csv")
        with patch.object(gui.filedialog, "asksaveasfilename", return_value=path):
            self.app.save_csv()
        with open(path, encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[1]["Status"], "Skipped")

    def test_document_import_duplicate_and_clear(self):
        path = Path(self.temp.name) / "input.txt"
        path.write_text("8.8.8.8 1.1.1.1")
        with patch.object(gui.filedialog, "askopenfilenames", return_value=[str(path)]):
            self.app.choose_files()
            self.finish()
            self.app.choose_files()
        self.assertEqual(len(self.app.rows), 2)
        self.assertEqual(self.app.rows["8.8.8.8"]["Occurrences"], 1)
        with patch.object(gui.messagebox, "askyesno", return_value=True):
            self.app.clear()
        self.assertEqual(self.app.rows, {})

    def test_failure_then_retry(self):
        self.add("8.8.8.8")
        with patch.object(gui, "OnlineLocator", self.fake(ValueError("Network unavailable"))):
            self.app.start_lookup()
            self.finish()
        self.assertEqual(self.app.rows["8.8.8.8"]["Status"], "Error")
        with patch.object(gui, "OnlineLocator", self.fake()):
            self.app.start_lookup()
            self.finish()
        self.assertEqual(self.app.rows["8.8.8.8"]["Status"], "Success")
        self.assertEqual(self.app.rows["8.8.8.8"]["Error"], "")

    def test_quota_stops_batch(self):
        self.add("8.8.8.8 1.1.1.1")
        with patch.object(gui, "OnlineLocator", self.fake(RateLimited("Quota reached"))):
            self.app.start_lookup()
            self.finish()
        self.assertEqual(self.app.rows["8.8.8.8"]["Status"], "Error")
        self.assertEqual(self.app.rows["1.1.1.1"]["Status"], "Pending")

    def test_stop_preserves_pending_rows(self):
        self.add("8.8.8.8 1.1.1.1")
        app = self.app
        class Locator:
            name = "Cancellation fixture"
            def lookup(self, ip):
                app.stop_event.set()
                return {"Country": "Test"}
            def close(self):
                pass
        with patch.object(gui, "OnlineLocator", Locator):
            self.app.start_lookup()
            self.finish()
        self.assertEqual(self.app.rows["8.8.8.8"]["Status"], "Success")
        self.assertEqual(self.app.rows["1.1.1.1"]["Status"], "Pending")

    def test_virustotal_requires_key(self):
        self.add("8.8.8.8")
        with patch.object(gui.messagebox, "showerror") as notice:
            self.app.start_vt()
            notice.assert_called_once()
        self.assertFalse(self.app.busy)

    def test_virustotal_selected_and_geolocation_preserved(self):
        self.add("8.8.8.8 1.1.1.1")
        self.app.rows["8.8.8.8"]["Country"] = "Preserved country"
        self.app.tree.selection_set("8.8.8.8")
        self.app.vt_key.set("a" * 64)
        class Client:
            def __init__(self, key):
                pass
            def close(self):
                pass
            def lookup(self, ip):
                return {"VT Status": "Success", "VT Malicious": 2, "VT Suspicious": 1}
        with patch.object(gui, "VirusTotalClient", Client):
            self.app.start_vt()
            self.finish()
        self.assertEqual(self.app.rows["8.8.8.8"]["VT Malicious"], 2)
        self.assertEqual(self.app.rows["8.8.8.8"]["Country"], "Preserved country")
        self.assertEqual(self.app.rows["1.1.1.1"]["VT Status"], "Not checked")
        self.app.rows["1.1.1.1"]["Status"] = "Success"
        with patch.object(gui, "OnlineLocator", self.fake()):
            self.app.start_lookup()
            self.finish()
        self.assertEqual(self.app.rows["8.8.8.8"]["VT Malicious"], 2)

    def test_virustotal_authentication_stops_batch(self):
        self.add("8.8.8.8 1.1.1.1")
        self.app.vt_key.set("a" * 64)
        class Client:
            def __init__(self, key):
                pass
            def close(self):
                pass
            def lookup(self, ip):
                raise gui.AuthenticationError("Key rejected")
        with patch.object(gui, "VirusTotalClient", Client):
            self.app.start_vt()
            self.finish()
        self.assertEqual(self.app.rows["8.8.8.8"]["VT Status"], "Error")
        self.assertEqual(self.app.rows["1.1.1.1"]["VT Status"], "Not checked")


if __name__ == "__main__":
    unittest.main()
