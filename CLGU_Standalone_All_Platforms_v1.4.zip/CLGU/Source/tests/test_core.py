import csv
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
from urllib.error import HTTPError, URLError
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import geo_core as core


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)

    def file(self, name, data):
        path = self.folder / name
        path.write_bytes(data if isinstance(data, bytes) else data.encode())
        return path

    def office(self, name, entries):
        path = self.folder / name
        with ZipFile(path, "w") as archive:
            for member, content in entries.items():
                archive.writestr(member, content)
        return path

    def test_ipv4_validation_and_boundaries(self):
        self.assertEqual(core.extract_ips("8.8.8.8:53 999.8.8.8 01.2.3.4 1.2.3.4.5 x8.8.4.4 1.1.1.1."), ["8.8.8.8", "1.1.1.1"])

    def test_ipv6_ports_zone_mapped_and_canonical(self):
        text = "[2606:4700:4700::1111]:443 2001:4860:4860:0:0:0:0:8888 ::1 fe80::1%eth0 ::ffff:192.168.1.1"
        self.assertEqual(core.extract_ips(text), ["2606:4700:4700::1111", "2001:4860:4860::8888", "::1", "fe80::1", "::ffff:192.168.1.1"])

    def test_cidr_is_not_expanded(self):
        self.assertEqual(core.extract_ips("8.8.8.0/24 2606:4700::/32"), ["8.8.8.0", "2606:4700::"])

    def test_unique_counts_sources(self):
        records = {}
        core.merge_source(records, "8.8.8.8 8.8.8.8", "a.docx")
        core.merge_source(records, "8.8.8.8 1.1.1.1", "b.odt")
        self.assertEqual(records["8.8.8.8"], {"count": 3, "sources": ["a.docx", "b.odt"]})
        self.assertEqual(list(records), ["8.8.8.8", "1.1.1.1"])

    def test_special_addresses_never_public(self):
        for ip in ["10.1.1.1", "127.0.0.1", "169.254.1.1", "100.64.1.1", "224.0.0.1", "203.0.113.1", "192.0.2.1", "::1", "fe80::1", "ff02::1", "2001:db8::1", "::ffff:192.168.1.1"]:
            with self.subTest(ip=ip):
                self.assertFalse(core.is_public(ip))
        self.assertTrue(core.is_public("8.8.8.8"))
        self.assertTrue(core.is_public("2606:4700:4700::1111"))

    def test_plain_encodings(self):
        for index, encoding in enumerate(["utf-8-sig", "utf-16", "utf-16-le", "utf-16-be", "cp1252"]):
            with self.subTest(encoding=encoding):
                path = self.file(f"sample{index}.txt", "IP: 8.8.8.8 café".encode(encoding))
                self.assertEqual(core.extract_ips(core.read_document(path)), ["8.8.8.8"])

    def test_docx_split_runs_table_header(self):
        path = self.office("word.docx", {
            "word/document.xml": '<w:document xmlns:w="urn:w"><w:p><w:r><w:t>8.8.</w:t></w:r><w:r><w:t>8.8</w:t></w:r></w:p><w:tbl><w:tr><w:tc><w:p><w:r><w:t>1.1.1.1</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:document>',
            "word/header1.xml": '<w:hdr xmlns:w="urn:w"><w:p><w:r><w:t>8.8.4.4</w:t></w:r></w:p></w:hdr>'})
        self.assertEqual(core.extract_ips(core.read_document(path)), ["8.8.8.8", "1.1.1.1", "8.8.4.4"])

    def test_odt_ods_odp_inline_spans(self):
        for ext in ["odt", "ods", "odp"]:
            path = self.office("document." + ext, {"content.xml": '<root xmlns:text="urn:text"><text:p>IP 8.8.<text:span>8.8</text:span></text:p><text:p>1.1.1.1</text:p></root>'})
            self.assertEqual(core.extract_ips(core.read_document(path)), ["8.8.8.8", "1.1.1.1"])

    def test_pptx_slides_and_notes(self):
        xml = '<a:root xmlns:a="urn:a"><a:p><a:r><a:t>8.8.8.8</a:t></a:r></a:p></a:root>'
        path = self.office("slides.pptx", {"ppt/slides/slide1.xml": xml, "ppt/notesSlides/notesSlide1.xml": xml.replace("8.8.8.8", "1.1.1.1")})
        self.assertEqual(core.extract_ips(core.read_document(path)), ["8.8.8.8", "1.1.1.1"])

    def test_word_tabs_separate_addresses(self):
        path = self.office("tabs.docx", {"word/document.xml": '<w:document xmlns:w="urn:w"><w:p><w:r><w:t>8.8.8.8</w:t><w:tab/><w:t>1.1.1.1</w:t><w:br/><w:t>8.8.4.4</w:t></w:r></w:p></w:document>'})
        self.assertEqual(core.extract_ips(core.read_document(path)), ["8.8.8.8", "1.1.1.1", "8.8.4.4"])

    def test_odf_explicit_spaces_separate_addresses(self):
        path = self.office("spaces.odt", {"content.xml": '<root xmlns:text="urn:text"><text:p>8.8.8.8<text:s/>1.1.1.1<text:tab/>8.8.4.4</text:p></root>'})
        self.assertEqual(core.extract_ips(core.read_document(path)), ["8.8.8.8", "1.1.1.1", "8.8.4.4"])

    def test_xlsx_multiple_tabs(self):
        from openpyxl import Workbook
        wb = Workbook()
        wb.active["A1"] = "8.8.8.8"
        wb.create_sheet("More")["B2"] = "2606:4700:4700::1111"
        path = self.folder / "sheet.xlsx"
        wb.save(path)
        wb.close()
        self.assertEqual(core.extract_ips(core.read_document(path)), ["8.8.8.8", "2606:4700:4700::1111"])

    def test_html_join_inline_ignore_scripts(self):
        path = self.file("page.html", '<p>8.8.<b>8.8</b></p><script>1.1.1.1</script><div>8.8.4.4</div>')
        self.assertEqual(core.extract_ips(core.read_document(path)), ["8.8.8.8", "8.8.4.4"])

    def test_rtf(self):
        path = self.file("note.rtf", r"{\rtf1\ansi IP: 8.8.8.8\par next 1.1.1.1}")
        self.assertEqual(core.extract_ips(core.read_document(path)), ["8.8.8.8", "1.1.1.1"])

    def test_pdf_with_text(self):
        try:
            from reportlab.pdfgen import canvas
        except ImportError:
            self.skipTest("Optional fixture generator reportlab not installed")
        path = self.folder / "text.pdf"
        c = canvas.Canvas(str(path))
        c.drawString(72, 700, "IP 8.8.8.8 and 2606:4700:4700::1111")
        c.save()
        self.assertEqual(core.extract_ips(core.read_document(path)), ["8.8.8.8", "2606:4700:4700::1111"])

    def test_image_only_pdf_reports_ocr(self):
        from pypdf import PdfWriter
        path = self.folder / "blank.pdf"
        writer = PdfWriter()
        writer.add_blank_page(width=600, height=800)
        writer.write(path)
        with self.assertRaisesRegex(ValueError, "OCR"):
            core.read_document(path)

    def test_legacy_doc_actionable_error(self):
        path = self.file("old.doc", b"legacy binary")
        with patch.object(core.shutil, "which", return_value=None), self.assertRaisesRegex(ValueError, "save as .docx"):
            core.read_document(path)

    def test_unknown_format_actionable_error(self):
        with self.assertRaisesRegex(ValueError, "Unsupported"):
            core.read_document(self.file("photo.png", b"fake"))

    def test_xml_entities_rejected(self):
        path = self.office("bad.odt", {"content.xml": '<!DOCTYPE root [<!ENTITY x "8.8.8.8">]><root><p>&x;</p></root>'})
        with self.assertRaises(Exception):
            core.read_document(path)

    def test_limits(self):
        path = self.file("big.txt", "IP 8.8.8.8")
        with patch.object(core, "MAX_BYTES", 2), self.assertRaisesRegex(ValueError, "64 MiB"):
            core.read_document(path)
        path = self.office("big.odt", {"content.xml": "<root>8.8.8.8</root>"})
        with patch.object(core, "MAX_XML_BYTES", 2), self.assertRaisesRegex(ValueError, "128 MiB"):
            core.read_document(path)

    def test_csv_mixed_rows_unicode_formula_and_numeric_coordinates(self):
        rows = [core.make_row("8.8.8.8", {"count": 2, "sources": ["=DANGEROUS.docx"]}),
                core.make_row("192.168.1.1", {"count": 1, "sources": ["café.odt"]})]
        rows[0].update({"Status": "Success", "Country": "United States", "Longitude": -122.1})
        path = self.folder / "output.csv"
        core.export_csv(path, rows)
        self.assertTrue(path.read_bytes().startswith(b"\xef\xbb\xbf"))
        with path.open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            actual = list(reader)
            self.assertEqual(reader.fieldnames, core.FIELDS)
        self.assertEqual(actual[0]["Sources"], "'=DANGEROUS.docx")
        self.assertEqual(actual[0]["Longitude"], "-122.1")
        self.assertEqual(actual[1]["Status"], "Skipped")
        self.assertEqual(actual[1]["Sources"], "café.odt")

    def test_empty_csv_has_headers(self):
        path = self.folder / "empty.csv"
        core.export_csv(path, [])
        self.assertEqual(len(path.read_text(encoding="utf-8-sig").splitlines()), 1)

    def test_atomic_csv_failure_preserves_old_file(self):
        path = self.file("out.csv", "original report")
        with patch.object(core.os, "replace", side_effect=PermissionError("locked")), self.assertRaises(PermissionError):
            core.export_csv(path, [])
        self.assertEqual(path.read_text(), "original report")
        self.assertEqual(list(self.folder.glob(".geolocator-*")), [])

    def locator(self, payload):
        locator = core.OnlineLocator()
        class Opener:
            def open(self, request, timeout):
                self.request = request
                if isinstance(payload, Exception):
                    raise payload
                return io.BytesIO(json.dumps(payload).encode())
        locator.opener = Opener()
        return locator

    def test_online_maps_fields_and_uses_https(self):
        locator = self.locator({"success": True, "ip": "8.8.8.8", "country": "US", "latitude": 0, "connection": {"isp": "Example", "asn": 15169}, "timezone": {"id": "Etc/UTC"}})
        result = locator.lookup("8.8.8.8")
        self.assertEqual(result["Latitude"], 0)
        self.assertEqual(result["ISP"], "Example")
        self.assertEqual(locator.opener.request.full_url, "https://ipwho.is/8.8.8.8")

    def test_online_rejects_nonpublic_and_mismatched_response(self):
        locator = self.locator({"success": True, "ip": "1.1.1.1"})
        with self.assertRaisesRegex(ValueError, "Non-public"):
            locator.lookup("127.0.0.1")
        with self.assertRaisesRegex(ValueError, "different IP"):
            locator.lookup("8.8.8.8")

    def test_rate_limits_http_and_json(self):
        for payload in [HTTPError("https://ipwho.is/8.8.8.8", 429, "limit", {}, None), {"success": False, "message": "Rate limit exceeded"}]:
            with self.subTest(payload=payload), self.assertRaises(core.RateLimited):
                self.locator(payload).lookup("8.8.8.8")

    def test_network_and_malformed_json_errors(self):
        with self.assertRaisesRegex(ValueError, "Network/TLS"):
            self.locator(URLError("offline")).lookup("8.8.8.8")
        with self.assertRaisesRegex(ValueError, "Unexpected"):
            self.locator([]).lookup("8.8.8.8")


if __name__ == "__main__":
    unittest.main()
