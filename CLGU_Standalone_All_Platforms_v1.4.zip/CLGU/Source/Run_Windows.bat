@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
    echo Install Python 3.10 or newer from https://www.python.org/downloads/windows/
    echo Include the Python launcher and Tcl/Tk components during installation.
    pause
    exit /b 1
)
py -3 -c "import sys, tkinter; assert sys.version_info >= (3,10)" >nul 2>nul
if errorlevel 1 (
    echo Python 3.10 or newer with Tcl/Tk is required. Modify your Python installation.
    pause
    exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv
    if errorlevel 1 goto failed
)
if not exist ".venv\requirements-installed.txt" goto install
fc /b requirements.txt .venv\requirements-installed.txt >nul 2>nul
if errorlevel 1 goto install
goto run
:install
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
copy /y requirements.txt .venv\requirements-installed.txt >nul
:run
".venv\Scripts\python.exe" ip_geolocator.py
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo Setup or launch failed. Check the error above and your internet connection.
pause
exit /b 1
