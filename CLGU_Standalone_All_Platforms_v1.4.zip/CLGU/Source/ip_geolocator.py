#!/usr/bin/env python3
"""Cross-platform desktop application. Run with Python 3.10 or newer."""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import queue
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from geo_core import (FIELDS, SUPPORTED, OnlineLocator, RateLimited, AuthenticationError,
                      ReportNotFound, VirusTotalClient,
                      export_csv, make_row, merge_source, read_document, utc_now)

APP_NAME = "Cute Little Geolocation Utility (CLGU)"
APP_ID = "CLGU.Desktop.Utility"
TOXIC_GREEN = "#7CFF00"
CREDIT_RED = "#FF4141"
ASSET_DIR = Path(__file__).resolve().parent / "assets"


class GeoLocatorApp:
    def __init__(self, root):
        self.root = root
        root.title(APP_NAME)
        root.geometry("1220x820")
        root.minsize(1020, 700)
        self.configure_app_icon()
        self.records, self.rows = {}, {}
        self.imported = set()
        self.paste_number = 0
        self.events = queue.Queue()
        self.stop_event = threading.Event()
        self.busy = False
        self.controls = []
        self.search = tk.StringVar()
        self.vt_key = tk.StringVar()
        self.vt_last_request = 0.0
        self.status = tk.StringVar(value="Add documents or paste text to begin. Nothing is sent during import.")
        self.counts = tk.StringVar(value="0 unique IPs")
        self.sort_column = ""
        self.sort_reverse = False
        self.build_ui()
        self.search.trace_add("write", lambda *_: self.refresh_table())
        root.protocol("WM_DELETE_WINDOW", self.close)
        self.poll_id = root.after(100, self.poll)

    def configure_app_icon(self):
        import sys
        self.app_icons = [tk.PhotoImage(file=str(ASSET_DIR / f"clgu_monster_{size}.png")) for size in (256, 64, 32, 16)]
        if sys.platform == "win32":
            self.root.iconbitmap(str(ASSET_DIR / "clgu_monster.ico"))
        self.root.iconphoto(True, *self.app_icons)

    def action(self, parent, text, command, **kwargs):
        button = ttk.Button(parent, text=text, command=command, **kwargs)
        self.controls.append(button)
        return button

    def build_ui(self):
        style = ttk.Style()
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("Title.TLabel", font=("Segoe UI", 23, "bold"), foreground=TOXIC_GREEN, background="#151A20")
        style.configure("Brand.TFrame", background="#151A20")
        style.configure("BrandSub.TLabel", foreground="#CBD5E1", background="#151A20")
        style.configure("BrandCredit.TLabel", font=("Segoe UI", 12), foreground=CREDIT_RED, background="#151A20")
        style.configure("Sub.TLabel", foreground="#526277")
        style.configure("Treeview", rowheight=27)
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
        style.configure("Go.TButton", padding=(15, 8))
        outer = ttk.Frame(self.root, padding=18)
        outer.pack(fill="both", expand=True)
        header = ttk.Frame(outer, style="Brand.TFrame", padding=(16, 10))
        header.pack(fill="x", pady=(0, 12))
        header.columnconfigure(0, weight=1)
        self.title_label = ttk.Label(header, text=APP_NAME, style="Title.TLabel", wraplength=1100, anchor="center", justify="center")
        self.title_label.grid(row=0, column=0, sticky="ew")
        self.credit_frame = ttk.Frame(header, style="Brand.TFrame")
        self.credit_frame.grid(row=1, column=0, pady=(6, 0))
        self.credit_hearts = []
        for side in ("left", "right"):
            heart = tk.Canvas(self.credit_frame, width=18, height=18, bg="#151A20", highlightthickness=0)
            heart.create_polygon(9,17, 1,9, 1,4, 4,1, 7,1, 9,4, 11,1, 14,1, 17,4, 17,9,
                                 fill=CREDIT_RED, outline="", smooth=True, splinesteps=24)
            heart.pack(side="left")
            self.credit_hearts.append(heart)
            if side == "left":
                self.credit_label = ttk.Label(self.credit_frame, text="by: CaptnCrypto & ChatGPT", style="BrandCredit.TLabel")
                self.credit_label.pack(side="left", padx=8)
        self.subtitle_label = ttk.Label(header, text="Import documents  >  Geolocate / check VirusTotal  >  Export CSV", style="BrandSub.TLabel")
        self.subtitle_label.grid(row=2, column=0, pady=(7, 0))
        header.bind("<Configure>", lambda event: self.title_label.configure(wraplength=max(400, event.width - 40)))

        toolbar = ttk.Frame(outer)
        toolbar.pack(fill="x")
        self.action(toolbar, "1  Add documents...", self.choose_files).pack(side="left")
        self.action(toolbar, "Clear workspace", self.clear).pack(side="left", padx=8)
        ttk.Label(toolbar, textvariable=self.counts).pack(side="right")
        ttk.Label(outer, text="Word / LibreOffice / text / CSV / spreadsheets / presentations / searchable PDF / RTF / HTML", style="Sub.TLabel").pack(anchor="w", pady=(6, 8))

        paste_box = ttk.LabelFrame(outer, text="Or paste text containing IP addresses", padding=8)
        paste_box.pack(fill="x")
        self.paste = tk.Text(paste_box, height=2, wrap="word", undo=True, font=("Consolas", 10))
        self.paste.pack(side="left", fill="both", expand=True)
        self.action(paste_box, "Add pasted text", self.add_paste).pack(side="left", padx=(8, 0))

        settings = ttk.LabelFrame(outer, text="Lookup settings", padding=10)
        settings.pack(fill="x", pady=10)
        ttk.Label(settings, text="Geolocation uses ipwho.is over HTTPS (no API key). Only IPs are sent; your documents stay local.", style="Sub.TLabel").pack(anchor="w", pady=(0, 6))
        key_row = ttk.Frame(settings)
        key_row.pack(fill="x")
        ttk.Label(key_row, text="VirusTotal API key (optional):").pack(side="left")
        self.key_entry = ttk.Entry(key_row, textvariable=self.vt_key, show="*", width=48)
        self.key_entry.pack(side="left", fill="x", expand=True, padx=8)
        self.action(key_row, "Clear key", lambda: self.vt_key.set("")).pack(side="left")
        ttk.Label(settings, text="VirusTotal checks selected rows, or all public IPs if none are selected. Reports only; no file uploads. Up to 4 lookups/minute.",
                  style="Sub.TLabel", wraplength=1100).pack(anchor="w", pady=(5, 0))

        actions = ttk.Frame(outer)
        actions.pack(fill="x", pady=(0, 8))
        self.action(actions, "2  Geolocate / retry unfinished", self.start_lookup, style="Go.TButton").pack(side="left")
        self.action(actions, "VirusTotal: selected / all", self.start_vt, style="Go.TButton").pack(side="left", padx=8)
        self.stop_button = ttk.Button(actions, text="Stop", command=self.cancel, state="disabled")
        self.stop_button.pack(side="left", padx=8)
        self.action(actions, "3  Export ALL rows to CSV...", self.save_csv, style="Go.TButton").pack(side="left")
        filter_row = ttk.Frame(outer)
        filter_row.pack(fill="x", pady=(0, 6))
        ttk.Label(filter_row, text="Filter results:").pack(side="left", padx=(0, 5))
        ttk.Entry(filter_row, textvariable=self.search, width=23).pack(side="left", fill="x", expand=True)

        table_box = ttk.Frame(outer)
        table_box.pack(fill="both", expand=True)
        first_columns = ["IP", "Status", "Country", "Region", "City", "ISP", "VT Status", "VT Malicious", "VT Suspicious", "Occurrences"]
        self.tree = ttk.Treeview(table_box, columns=FIELDS, displaycolumns=first_columns + [f for f in FIELDS if f not in first_columns],
                                 show="headings", selectmode="extended", height=4)
        for field in FIELDS:
            width = 130
            if field in {"IP", "Organization", "ISP", "Provider"}:
                width = 190
            if field in {"Sources", "Error"}:
                width = 290
            if field in {"Version", "Status", "Occurrences"}:
                width = 95
            self.tree.heading(field, text=field, command=lambda f=field: self.sort_by(f))
            self.tree.column(field, width=width, minwidth=70, stretch=False)
        self.tree.tag_configure("Skipped", foreground="#6b7280")
        self.tree.tag_configure("Error", foreground="#ad2929")
        self.tree.tag_configure("Success", foreground="#17624c")
        self.tree.grid(row=0, column=0, sticky="nsew")
        vs = ttk.Scrollbar(table_box, orient="vertical", command=self.tree.yview)
        vs.grid(row=0, column=1, sticky="ns")
        hs = ttk.Scrollbar(table_box, orient="horizontal", command=self.tree.xview)
        hs.grid(row=1, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        self.tree.bind("<Double-1>", self.show_details)
        self.tree.bind("<Control-c>", self.copy_ips)
        table_box.rowconfigure(0, weight=1)
        table_box.columnconfigure(0, weight=1)
        self.progress = ttk.Progressbar(outer, mode="determinate")
        self.progress.pack(fill="x", pady=(10, 4))
        ttk.Label(outer, textvariable=self.status, wraplength=1130).pack(anchor="w")
        ttk.Label(outer, text="Locations are approximate. VirusTotal reports are reputation signals; zero detections do not prove safety. Double-click for details. CSV includes every row.",
                  style="Sub.TLabel", wraplength=1130).pack(anchor="w", pady=(5, 0))

    def set_busy(self, value):
        self.busy = value
        for control in self.controls:
            control.configure(state="disabled" if value else "normal")
        self.key_entry.configure(state="disabled" if value else "normal")
        self.paste.configure(state="disabled" if value else "normal")
        self.stop_button.configure(state="normal" if value else "disabled")

    def choose_files(self):
        paths = filedialog.askopenfilenames(title="Import documents containing IP addresses", filetypes=[
            ("Supported documents", " ".join("*" + ext for ext in sorted(SUPPORTED))), ("All files", "*")])
        paths = [str(Path(p).resolve()) for p in paths if str(Path(p).resolve()) not in self.imported]
        if not paths:
            return
        self.stop_event.clear()
        self.set_busy(True)
        self.progress.configure(value=0, maximum=len(paths))
        self.status.set("Reading documents locally...")
        threading.Thread(target=self.import_worker, args=(paths,), daemon=True).start()

    def import_worker(self, paths):
        errors = []
        try:
            for index, path in enumerate(paths, 1):
                if self.stop_event.is_set():
                    break
                self.events.put(("status", f"Reading {Path(path).name}..."))
                try:
                    text = read_document(path)
                    self.events.put(("import", (path, text)))
                except Exception as exc:
                    errors.append(f"{Path(path).name}: {exc}")
                self.events.put(("progress", index))
        finally:
            self.events.put(("import_done", errors))

    def add_paste(self):
        text = self.paste.get("1.0", "end-1c")
        if not text.strip():
            return
        self.paste_number += 1
        count = merge_source(self.records, text, f"Pasted text {self.paste_number}")
        self.sync_rows()
        self.paste.delete("1.0", "end")
        self.status.set(f"Added {count} valid IP occurrences from pasted text.")

    def sync_rows(self):
        for ip, record in self.records.items():
            base = make_row(ip, record)
            if ip in self.rows:
                self.rows[ip].update({"Occurrences": base["Occurrences"], "Sources": base["Sources"]})
            else:
                self.rows[ip] = base
        self.refresh_table()

    def refresh_table(self):
        query = self.search.get().casefold()
        selected = set(self.tree.selection())
        self.tree.delete(*self.tree.get_children())
        rows = [r for r in self.rows.values() if not query or query in " ".join(str(v) for v in r.values()).casefold()]
        if self.sort_column:
            field = self.sort_column
            def key(row):
                value = row.get(field, "")
                try:
                    return (0, float(value))
                except (ValueError, TypeError):
                    return (1, str(value).casefold())
            rows.sort(key=key, reverse=self.sort_reverse)
        for row in rows:
            self.tree.insert("", "end", iid=row["IP"], values=[row.get(f, "") for f in FIELDS], tags=(row["Status"],))
        visible_selected = [ip for ip in selected if self.tree.exists(ip)]
        if visible_selected:
            self.tree.selection_set(visible_selected)
        counts = Counter(row["Status"] for row in self.rows.values())
        self.counts.set(f"{len(self.rows)} unique IPs | {counts['Success']} located | {counts['Skipped']} skipped | {counts['Error']} errors")

    def sort_by(self, field):
        self.sort_reverse = not self.sort_reverse if self.sort_column == field else False
        self.sort_column = field
        self.refresh_table()

    def start_lookup(self):
        pending = [(ip, row.copy()) for ip, row in self.rows.items() if row["Status"] in {"Pending", "Error"}]
        if not pending:
            messagebox.showinfo("Nothing pending", "Import public IP addresses first. Successful lookups are kept until you clear the workspace.")
            return
        self.stop_event.clear()
        self.set_busy(True)
        self.progress.configure(value=0, maximum=len(pending))
        self.status.set(f"Looking up {len(pending)} public IPs...")
        threading.Thread(target=self.lookup_worker, args=(pending,), daemon=True).start()

    def lookup_worker(self, pending):
        locator = None
        summary = "Lookups complete. Export CSV to save your results."
        try:
            locator = OnlineLocator()
            last_request = 0.0
            for index, (ip, row) in enumerate(pending, 1):
                if self.stop_event.is_set():
                    summary = "Stopped. Completed results are retained; remaining rows stay pending."
                    break
                if self.stop_event.wait(max(0, 1.1 - (time.monotonic() - last_request))):
                    summary = "Stopped. Export partial results or retry unfinished lookups."
                    break
                self.events.put(("status", f"Geolocating {index}/{len(pending)}: {ip}"))
                # Remove stale values if a previously failed row is retried.
                vt_fields = {k: v for k, v in row.items() if k.startswith("VT ")}
                row = make_row(ip, {"count": row["Occurrences"], "sources": self.records[ip]["sources"]})
                row.update(vt_fields)
                row.update({"Provider": locator.name, "Lookup UTC": utc_now()})
                limited = False
                try:
                    last_request = time.monotonic()
                    row.update(locator.lookup(ip))
                    row.update({"Status": "Success", "Error": ""})
                except RateLimited as exc:
                    row.update({"Status": "Error", "Error": str(exc)})
                    limited = True
                    summary = "Provider rate/quota limit reached. Stopped; export partial results and retry later."
                except Exception as exc:
                    row.update({"Status": "Error", "Error": str(exc)})
                self.events.put(("row", row))
                self.events.put(("progress", index))
                if limited:
                    break
        except Exception as exc:
            summary = f"Could not start lookup: {exc}"
        finally:
            if locator:
                locator.close()
            self.events.put(("lookup_done", summary))

    def start_vt(self):
        selected = set(self.tree.selection())
        pending = [(ip, row.copy()) for ip, row in self.rows.items()
                   if (not selected or ip in selected) and row["VT Status"] in {"Not checked", "Error"}]
        if not pending:
            messagebox.showinfo("Nothing to check", "Import public IPs first. VirusTotal checks selected rows, or all rows if none are selected. Completed checks are retained until you clear the workspace.")
            return
        key = self.vt_key.get().strip()
        try:
            client = VirusTotalClient(key)
            client.close()
        except Exception as exc:
            messagebox.showerror("VirusTotal API key", str(exc))
            return
        self.stop_event.clear()
        self.set_busy(True)
        self.progress.configure(value=0, maximum=len(pending))
        self.status.set(f"Checking {len(pending)} IPs against VirusTotal. API requests are spaced 16 seconds apart.")
        threading.Thread(target=self.vt_worker, args=(pending, key), daemon=True).start()

    def vt_worker(self, pending, key):
        client = None
        summary = "VirusTotal checks complete. Export CSV to save the combined results."
        try:
            client = VirusTotalClient(key)
            key = ""
            for index, (ip, row) in enumerate(pending, 1):
                delay = max(0, 16 - (time.monotonic() - self.vt_last_request))
                if delay:
                    self.events.put(("status", f"VirusTotal: waiting {delay:.0f}s for rate limit; next IP {index}/{len(pending)}: {ip}"))
                if self.stop_event.wait(delay):
                    summary = "VirusTotal stopped. Completed results are retained; unchecked rows can be retried."
                    break
                self.events.put(("status", f"VirusTotal {index}/{len(pending)}: {ip}"))
                for field in row:
                    if field.startswith("VT "):
                        row[field] = ""
                row.update({"VT Lookup UTC": utc_now(), "VT Report URL": "https://www.virustotal.com/gui/ip-address/" + ip})
                stop_batch = False
                try:
                    self.vt_last_request = time.monotonic()
                    row.update(client.lookup(ip))
                except ReportNotFound as exc:
                    row.update({"VT Status": "Not found", "VT Error": str(exc)})
                except (RateLimited, AuthenticationError) as exc:
                    row.update({"VT Status": "Error", "VT Error": str(exc)})
                    stop_batch = True
                    summary = f"VirusTotal stopped: {exc} Export partial results or retry later."
                except Exception as exc:
                    row.update({"VT Status": "Error", "VT Error": str(exc)})
                self.events.put(("row", row))
                self.events.put(("progress", index))
                if stop_batch:
                    break
        except Exception as exc:
            summary = f"Could not start VirusTotal checks: {exc}"
        finally:
            key = ""
            if client:
                client.close()
            self.events.put(("lookup_done", summary))

    def cancel(self):
        self.stop_event.set()
        self.status.set("Stopping after the current document/request finishes (network timeout: 15 seconds)...")
        self.stop_button.configure(state="disabled")

    def poll(self):
        dirty = False
        for _ in range(300):
            try:
                kind, value = self.events.get_nowait()
            except queue.Empty:
                break
            if kind == "import":
                path, text = value
                count = merge_source(self.records, text, path)
                self.imported.add(path)
                self.status.set(f"Imported {Path(path).name}: {count} valid IP occurrences.")
                self.sync_rows()
            elif kind == "row":
                self.rows[value["IP"]] = value
                dirty = True
            elif kind == "progress":
                self.progress.configure(value=value)
            elif kind == "status":
                self.status.set(value)
            elif kind == "import_done":
                self.set_busy(False)
                self.status.set(f"Import {'stopped' if self.stop_event.is_set() else 'complete'}. {len(self.rows)} unique valid IPs. {len(value)} file errors. Ready to geolocate or export.")
                if value:
                    self.text_dialog("Document import errors", "\n\n".join(value))
            elif kind == "lookup_done":
                self.set_busy(False)
                self.status.set(value)
        if dirty:
            self.refresh_table()
        self.poll_id = self.root.after(100, self.poll)

    def save_csv(self):
        if not self.rows:
            messagebox.showinfo("No IPs", "Import a document or add pasted text first.")
            return
        filename = filedialog.asksaveasfilename(title="Export all IP results", defaultextension=".csv", initialfile="ip_geolocation.csv", filetypes=[("CSV spreadsheet", "*.csv")])
        if not filename:
            return
        try:
            export_csv(filename, self.rows.values())
            self.status.set(f"Exported all {len(self.rows)} rows to {filename}")
        except Exception as exc:
            messagebox.showerror("Export failed", str(exc))

    def clear(self):
        if self.rows and not messagebox.askyesno("Clear workspace?", "Clear imported IPs and results? Export CSV first if you need to keep them."):
            return
        self.records.clear()
        self.rows.clear()
        self.imported.clear()
        self.search.set("")
        self.paste.delete("1.0", "end")
        self.progress.configure(value=0)
        self.refresh_table()
        self.status.set("Workspace cleared. Add documents or paste text.")

    def text_dialog(self, title, text):
        window = tk.Toplevel(self.root)
        window.title(title)
        window.geometry("760x480")
        box = tk.Text(window, wrap="word", padx=12, pady=12)
        box.pack(fill="both", expand=True)
        box.insert("1.0", text)
        box.configure(state="disabled")
        ttk.Button(window, text="Close", command=window.destroy).pack(pady=8)

    def show_details(self, event=None):
        selection = self.tree.selection()
        if selection:
            row = self.rows[selection[0]]
            self.text_dialog("IP details", "\n\n".join(f"{f}: {row.get(f, '')}" for f in FIELDS))

    def copy_ips(self, event=None):
        self.root.clipboard_clear()
        self.root.clipboard_append("\n".join(self.tree.selection()))
        return "break"

    def close(self):
        if self.rows and not messagebox.askyesno("Close IP GeoLocator?", "Results are kept in memory only. Have you exported any results you want to keep?"):
            return
        self.shutdown()

    def shutdown(self):
        self.stop_event.set()
        self.vt_key.set("")
        self.root.after_cancel(self.poll_id)
        self.root.destroy()


def main():
    import sys
    if sys.platform == "win32":
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    if len(sys.argv) == 3 and sys.argv[1] == "--self-test":
        from self_test import run
        run(sys.argv[2])
        return
    root = tk.Tk(className="CLGU")
    GeoLocatorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
