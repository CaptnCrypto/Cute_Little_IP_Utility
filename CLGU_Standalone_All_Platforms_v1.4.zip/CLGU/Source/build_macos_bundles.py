"""Assemble self-contained Intel and Apple Silicon .app bundles from verified runtimes.

Build-only dependencies: Pillow. This can assemble bundles on Linux; launch testing,
Apple code signing and notarization require a Mac. Never claim assembly is a native test.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import plistlib
import shutil
import stat
import struct

ARCHES = {"arm64": (0x100000C, "Apple_Silicon", "11.0"),
          "x86_64": (0x1000007, "Intel", "10.15")}
MODULES = {"pypdf", "openpyxl", "xlrd", "striprtf", "defusedxml", "certifi", "et_xmlfile"}


def macho_info(path):
    data = path.read_bytes()
    if data[:4] != b"\xcf\xfa\xed\xfe":
        return None
    header = struct.unpack_from("<IiiIIIII", data)
    position, dependencies, rpaths, minimum = 32, [], [], (0, 0, 0)
    for _ in range(header[4]):
        cmd, size = struct.unpack_from("<II", data, position)
        if size < 8 or position + size > len(data):
            raise ValueError(f"Invalid Mach-O load command: {path}")
        if cmd in (0x24, 0x32):
            version = struct.unpack_from("<I", data, position + (12 if cmd == 0x32 else 8))[0]
            minimum = (version >> 16, (version >> 8) & 255, version & 255)
        if cmd in (0xC, 0x80000018, 0x8000001F, 0x80000023, 0x8000001C):
            offset = struct.unpack_from("<I", data, position + 8)[0]
            value = data[position + offset:position + size].split(b"\0", 1)[0].decode()
            if cmd == 0x8000001C:
                rpaths.append(value)
            else:
                dependencies.append({"path": value, "weak": cmd == 0x80000018})
        position += size
    return {"cpu": header[1], "minimum_os": minimum, "dependencies": dependencies, "rpaths": rpaths}


def prune_runtime(runtime):
    for name in ["include", "share/man", "lib/python3.12/test", "lib/python3.12/idlelib",
                 "lib/python3.12/ensurepip", "lib/python3.12/turtledemo"]:
        shutil.rmtree(runtime / name, ignore_errors=True)
    for path in list(runtime.rglob("__pycache__")):
        shutil.rmtree(path, ignore_errors=True)
    for path in list(runtime.rglob("*.a")):
        path.unlink()
    site = runtime / "lib/python3.12/site-packages"
    for path in site.glob("pip*"):
        if path.is_dir():
            shutil.rmtree(path)
        else:
            path.unlink()
    for path in (runtime / "bin").glob("pip*"):
        path.unlink()


def copy_dependencies(source_site, destination):
    destination.mkdir(parents=True, exist_ok=True)
    for module in MODULES:
        source = source_site / module
        if not source.is_dir():
            raise ValueError(f"Missing pure-Python dependency: {module}")
        if any(p.suffix.lower() in {".so", ".pyd", ".dll"} for p in source.rglob("*")):
            raise ValueError(f"Native dependency must use a macOS-specific wheel: {module}")
        shutil.copytree(source, destination / module, dirs_exist_ok=True, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        for metadata in source_site.glob(module + "-*.dist-info"):
            shutil.copytree(metadata, destination / metadata.name, dirs_exist_ok=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtimes", type=Path, required=True, help="Parent of arm64/python and x86_64/python")
    parser.add_argument("--dependencies", type=Path, required=True, help="Reviewed pure-Python site-packages directory")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    from PIL import Image
    reports = []
    for arch, (cpu, folder, minimum_os) in ARCHES.items():
        original_runtime = args.runtimes / arch / "python"
        app = args.output / folder / "CLGU.app"
        if app.exists():
            raise ValueError(f"Output already exists: {app}")
        contents = app / "Contents"
        resources = contents / "Resources"
        executable_dir = contents / "MacOS"
        resources.mkdir(parents=True)
        executable_dir.mkdir()
        runtime = resources / "runtime"
        shutil.copytree(original_runtime, runtime, symlinks=True)
        prune_runtime(runtime)
        copy_dependencies(args.dependencies, runtime / "lib/python3.12/site-packages")
        app_source = resources / "app"
        app_source.mkdir()
        for name in ("ip_geolocator.py", "geo_core.py", "self_test.py", "bootstrap_macos.py"):
            shutil.copy2(source / name, app_source / name)
        shutil.copytree(source / "assets", app_source / "assets")
        Image.open(source / "assets/clgu_monster_original.png").convert("RGBA").resize((1024, 1024), Image.Resampling.LANCZOS).save(resources / "CLGU.icns", format="ICNS")
        launcher = executable_dir / "CLGU"
        launcher.write_text('''#!/bin/sh
set -eu
CLGU_CONTENTS="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
CLGU_RESOURCES="$CLGU_CONTENTS/Resources"
unset PYTHONHOME PYTHONPATH TCL_LIBRARY TK_LIBRARY DYLD_LIBRARY_PATH DYLD_FRAMEWORK_PATH
export TCL_LIBRARY="$CLGU_RESOURCES/runtime/lib/tcl9.0"
export TK_LIBRARY="$CLGU_RESOURCES/runtime/lib/tk9.0"
exec "$CLGU_RESOURCES/runtime/bin/python3.12" -I -B "$CLGU_RESOURCES/app/bootstrap_macos.py" "$@"
''')
        launcher.chmod(0o755)
        plist = {
            "CFBundleExecutable": "CLGU", "CFBundleName": "CLGU",
            "CFBundleDisplayName": "Cute Little Geolocation Utility (CLGU)",
            "CFBundleIdentifier": "local.clgu.utility", "CFBundlePackageType": "APPL",
            "CFBundleInfoDictionaryVersion": "6.0", "CFBundleVersion": "1.4.0",
            "CFBundleShortVersionString": "1.4.0", "CFBundleIconFile": "CLGU.icns",
            "LSMinimumSystemVersion": minimum_os, "LSArchitecturePriority": [arch],
            "LSApplicationCategoryType": "public.app-category.utilities",
            "NSHighResolutionCapable": True, "LSUIElement": False,
        }
        with (contents / "Info.plist").open("wb") as stream:
            plistlib.dump(plist, stream)
        binary_reports = []
        for path in runtime.rglob("*"):
            if path.is_symlink():
                target = path.resolve()
                if not target.exists() or not target.is_relative_to(runtime.resolve()):
                    raise ValueError(f"Broken or external runtime symlink: {path}")
            elif path.is_file():
                info = macho_info(path)
                if info:
                    if info["cpu"] != cpu:
                        raise ValueError(f"Wrong architecture: {path}")
                    for dep in info["dependencies"]:
                        value = dep["path"]
                        if not value.startswith(("@", "/usr/lib/", "/System/Library/")):
                            raise ValueError(f"Unbundled absolute dependency: {path}: {value}")
                    # Original native bytes, including embedded code signatures, are retained.
                    original = original_runtime / path.relative_to(runtime)
                    if hashlib.sha256(path.read_bytes()).digest() != hashlib.sha256(original.read_bytes()).digest():
                        raise ValueError(f"Native runtime modified: {path}")
                    binary_reports.append({"file": str(path.relative_to(runtime)), **info})
        if not (runtime / "lib/tcl9.0/init.tcl").is_file() or not (runtime / "lib/tk9.0/tk.tcl").is_file():
            raise ValueError("Bundled Tcl/Tk resources are incomplete")
        assert not list(app.rglob("*fdle*"))
        reports.append({"architecture": arch, "bundle": str(app), "minimum_os": minimum_os,
                        "native_file_count": len(binary_reports), "native_files": binary_reports,
                        "native_launch_tested": False, "apple_signed_or_notarized_bundle": False})
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "macos_build_validation.json").write_text(json.dumps(reports, indent=2))
    for report in reports:
        print(report["architecture"], report["bundle"], "native files checked:", report["native_file_count"])


if __name__ == "__main__":
    main()
