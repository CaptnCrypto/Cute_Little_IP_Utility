@echo off
setlocal
cd /d "%~dp0"
echo Build a Windows executable on a Windows computer with Python 3.10+ installed.
py -3 -m venv .build-venv
if errorlevel 1 goto failed
".build-venv\Scripts\python.exe" -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto failed
".build-venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name CLGU --icon assets\clgu_monster.ico --add-data "assets;assets" --collect-all certifi --collect-all striprtf --collect-all defusedxml --collect-all pypdf --collect-all openpyxl --collect-all xlrd ip_geolocator.py
if errorlevel 1 goto failed
echo.
echo Built: dist\CLGU.exe
echo Copy that executable to another Windows machine; Python is not required there.
pause
exit /b 0
:failed
echo Build failed. Review the error above.
pause
exit /b 1
