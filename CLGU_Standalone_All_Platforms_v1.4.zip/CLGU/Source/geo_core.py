"""Document extraction, IP validation, geolocation and CSV export. Python 3.10+."""
from __future__ import annotations

import csv
from bisect import bisect_right
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import ssl
import subprocess
import tempfile
from collections import Counter
from datetime import datetime, timezone
from html.parser import HTMLParser
from urllib.error import HTTPError, URLError
from urllib.request import Request, build_opener, HTTPSHandler, HTTPRedirectHandler
from zipfile import ZipFile

FIELDS = ["IP", "Version", "Status", "Country", "Country Code", "Region", "City",
          "Postal", "ISP", "Organization", "ASN", "Latitude", "Longitude", "Timezone",
          "Occurrences", "Sources", "Provider", "Lookup UTC", "Error",
          "VT Status", "VT Malicious", "VT Suspicious", "VT Harmless", "VT Undetected",
          "VT Timeout", "VT Reputation", "VT Last Analysis UTC", "VT Lookup UTC", "VT Report URL", "VT Error"]
TEXT_EXTS = {".txt", ".csv", ".tsv", ".log", ".md", ".json", ".xml", ".yaml", ".yml", ".ini", ".conf", ".eml"}
SUPPORTED = TEXT_EXTS | {".docx", ".odt", ".ods", ".odp", ".pptx", ".xlsx", ".xls", ".pdf", ".rtf", ".html", ".htm", ".doc"}
MAX_BYTES = 64 * 1024 * 1024
MAX_XML_BYTES = 128 * 1024 * 1024


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def decode_text(data):
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16")
    if b"\0" in data[:2048]:
        for encoding in ("utf-16-le", "utf-16-be"):
            try:
                value = data.decode(encoding)
                if value.count("\0") < 2 and sum(c.isascii() for c in value) > len(value) // 2:
                    return value
            except UnicodeError:
                pass
        raise ValueError("Binary file or unsupported text encoding. Save as UTF-8 text.")
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace")


class HTMLText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.hidden = 0

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style"}:
            self.hidden += 1
        if tag in {"p", "div", "br", "td", "tr", "li"}:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in {"script", "style"}:
            self.hidden = max(0, self.hidden - 1)
        if tag in {"p", "div", "td", "tr", "li"}:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


def office_text(path):
    from defusedxml import ElementTree as ET
    ext = path.suffix.lower()
    with ZipFile(path) as archive:
        if sum(i.file_size for i in archive.infolist()) > MAX_XML_BYTES:
            raise ValueError("Office document expands beyond the 128 MiB safety limit.")
        names = archive.namelist()
        if ext == ".docx":
            selected = [n for n in names if re.fullmatch(r"word/(document|header\d+|footer\d+|footnotes|endnotes|comments)\.xml", n)]
        elif ext == ".pptx":
            selected = [n for n in names if re.fullmatch(r"ppt/(slides/slide\d+|notesSlides/notesSlide\d+)\.xml", n)]
        else:
            selected = ["content.xml"]
        parts = []
        for name in selected:
            root = ET.fromstring(archive.read(name))
            for element in root.iter():
                local = element.tag.rsplit("}", 1)[-1]
                if local in {"p", "h"}:
                    # Join formatting runs within a paragraph so split IPs survive.
                    if ext in {".docx", ".pptx"}:
                        fragments = []
                        for node in element.iter():
                            tag = node.tag.rsplit("}", 1)[-1]
                            if tag == "t":
                                fragments.append(node.text or "")
                            elif tag in {"tab", "br", "cr"}:
                                fragments.append("\n")
                        parts.append("".join(fragments))
                    else:
                        def odf_text(node):
                            text = node.text or ""
                            for child in node:
                                tag = child.tag.rsplit("}", 1)[-1]
                                text += (" " if tag in {"s", "tab", "line-break"} else odf_text(child)) + (child.tail or "")
                            return text
                        parts.append(odf_text(element))
        return "\n".join(parts)


def read_document(filename):
    path = Path(filename)
    if path.stat().st_size > MAX_BYTES:
        raise ValueError("File exceeds the 64 MiB input limit. Split it into smaller files.")
    ext = path.suffix.lower()
    if ext in {".docx", ".odt", ".ods", ".odp", ".pptx"}:
        return office_text(path)
    if ext == ".xlsx":
        from openpyxl import load_workbook
        with ZipFile(path) as archive:
            if sum(i.file_size for i in archive.infolist()) > MAX_XML_BYTES:
                raise ValueError("Workbook expands beyond 128 MiB.")
        wb = load_workbook(path, read_only=True, data_only=False, keep_links=False)
        try:
            return "\n".join(str(value) for sheet in wb for row in sheet.iter_rows(values_only=True) for value in row if value is not None)
        finally:
            wb.close()
    if ext == ".xls":
        import xlrd
        wb = xlrd.open_workbook(str(path), on_demand=True)
        try:
            return "\n".join(str(sheet.cell_value(r, c)) for sheet in wb.sheets() for r in range(sheet.nrows) for c in range(sheet.ncols))
        finally:
            wb.release_resources()
    if ext == ".pdf":
        from pypdf import PdfReader
        reader = PdfReader(str(path))
        if reader.is_encrypted and not reader.decrypt(""):
            raise ValueError("Password-protected PDF: export an unlocked copy first.")
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
        if not text.strip():
            raise ValueError("PDF has no extractable text. Run OCR first, then import it again.")
        return text
    if ext == ".rtf":
        from striprtf.striprtf import rtf_to_text
        return rtf_to_text(decode_text(path.read_bytes()))
    if ext == ".doc":
        antiword = shutil.which("antiword")
        if not antiword:
            raise ValueError("Legacy .doc: save as .docx, .odt or .txt in Word/LibreOffice first. Linux can also install antiword.")
        result = subprocess.run([antiword, str(path.resolve())], capture_output=True, timeout=30)
        if result.returncode:
            raise ValueError("Cannot read legacy .doc. Save as .docx or .odt first.")
        return decode_text(result.stdout)
    if ext in {".html", ".htm"}:
        parser = HTMLText()
        parser.feed(decode_text(path.read_bytes()))
        return "".join(parser.parts)
    if ext in TEXT_EXTS or not ext:
        return decode_text(path.read_bytes())
    raise ValueError(f"Unsupported format {ext}. Export text, DOCX, ODT, CSV or a searchable PDF.")


V6 = re.compile(r"(?<![\w:])(?:[0-9a-fA-F]{0,4}:){2,}[0-9a-fA-F:.]*(?:%[A-Za-z0-9_.-]+)?(?![\w:])")
V4 = re.compile(r"(?<![\w.])(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?!\w|\.\d)")


def extract_ips(text):
    """Canonical valid IPs, in source order; ports/CIDR masks are not expanded."""
    found, spans = [], []
    for match in V6.finditer(text):
        spans.append(match.span())
        raw = match.group().rstrip(".").split("%", 1)[0]
        try:
            found.append((match.start(), str(ipaddress.ip_address(raw))))
        except ValueError:
            pass
    starts = [start for start, _ in spans]
    for match in V4.finditer(text):
        preceding = bisect_right(starts, match.start()) - 1
        if preceding >= 0 and match.start() < spans[preceding][1]:
            continue
        try:
            found.append((match.start(), str(ipaddress.ip_address(match.group()))))
        except ValueError:
            pass
    return [value for _, value in sorted(found)]


def merge_source(records, text, source):
    counts = Counter(extract_ips(text))
    for ip, count in counts.items():
        record = records.setdefault(ip, {"count": 0, "sources": []})
        record["count"] += count
        if source not in record["sources"]:
            record["sources"].append(source)
    return sum(counts.values())


def is_public(ip):
    address = ipaddress.ip_address(ip)
    if address.version == 6 and address.ipv4_mapped:
        address = address.ipv4_mapped
    return address.is_global and not address.is_multicast and not address.is_reserved


def make_row(ip, record):
    row = dict.fromkeys(FIELDS, "")
    row.update({"IP": ip, "Version": f"IPv{ipaddress.ip_address(ip).version}",
                "Status": "Pending" if is_public(ip) else "Skipped",
                "VT Status": "Not checked" if is_public(ip) else "Skipped",
                "Occurrences": record["count"], "Sources": " | ".join(record["sources"])})
    if row["Status"] == "Skipped":
        row["Error"] = "Non-public / special-use address; not geolocated"
    return row


class RateLimited(Exception):
    pass


class AuthenticationError(Exception):
    pass


class ReportNotFound(Exception):
    pass


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args):
        return None


class OnlineLocator:
    name = "ipwho.is (HTTPS)"

    def __init__(self):
        import certifi
        context = ssl.create_default_context()
        context.load_verify_locations(cafile=certifi.where())
        self.opener = build_opener(HTTPSHandler(context=context), NoRedirect())

    def close(self):
        pass

    def lookup(self, ip):
        # Validate at this boundary too. Never request arbitrary URLs/hosts.
        ip = str(ipaddress.ip_address(ip))
        if not is_public(ip):
            raise ValueError("Non-public IP cannot be sent to the provider.")
        request = Request("https://ipwho.is/" + ip, headers={"User-Agent": "IPGeoLocator/1.0", "Accept": "application/json"})
        try:
            with self.opener.open(request, timeout=15) as response:
                raw = response.read(1024 * 1024 + 1)
                if len(raw) > 1024 * 1024:
                    raise ValueError("Provider response exceeded 1 MiB")
                data = json.loads(raw)
        except HTTPError as exc:
            if exc.code == 429:
                raise RateLimited("Provider quota/rate limit reached. Retry later; export partial results now.") from exc
            raise ValueError(f"Provider HTTP error {exc.code}") from exc
        except URLError as exc:
            raise ValueError(f"Network/TLS error: {exc.reason}") from exc
        if not isinstance(data, dict):
            raise ValueError("Unexpected provider response")
        if data.get("success") is not True:
            message = str(data.get("message", "Lookup failed"))
            if any(word in message.lower() for word in ("limit", "quota")):
                raise RateLimited(message)
            raise ValueError(message)
        if str(ipaddress.ip_address(data.get("ip", ""))) != ip:
            raise ValueError("Provider returned a different IP")
        connection = data.get("connection") or {}
        tz = data.get("timezone") or {}
        return {"Country": data.get("country", ""), "Country Code": data.get("country_code", ""),
                "Region": data.get("region", ""), "City": data.get("city", ""), "Postal": data.get("postal", ""),
                "ISP": connection.get("isp", ""), "Organization": connection.get("org", ""),
                "ASN": connection.get("asn", ""), "Latitude": data.get("latitude", ""),
                "Longitude": data.get("longitude", ""), "Timezone": tz.get("id", "")}


class VirusTotalClient:
    """Read existing IP reputation reports only. Never uploads or submits scans."""
    def __init__(self, api_key):
        if not re.fullmatch(r"[A-Za-z0-9_-]{16,256}", api_key):
            raise ValueError("Enter a valid VirusTotal API key (no spaces).")
        self._api_key = api_key
        self.opener = OnlineLocator().opener

    def close(self):
        self._api_key = ""

    def lookup(self, ip):
        ip = str(ipaddress.ip_address(ip))
        if not is_public(ip):
            raise ValueError("Non-public IP cannot be sent to VirusTotal.")
        request = Request("https://www.virustotal.com/api/v3/ip_addresses/" + ip,
                          headers={"x-apikey": self._api_key, "Accept": "application/json", "User-Agent": "IPGeoLocator/1.1"})
        try:
            with self.opener.open(request, timeout=15) as response:
                raw = response.read(4 * 1024 * 1024 + 1)
                if len(raw) > 4 * 1024 * 1024:
                    raise ValueError("VirusTotal response exceeded 4 MiB")
                payload = json.loads(raw)
        except HTTPError as exc:
            if exc.code == 429:
                raise RateLimited("VirusTotal rate/quota limit reached. Retry later.") from None
            if exc.code in {401, 403}:
                raise AuthenticationError("VirusTotal rejected the API key or its permissions.") from None
            if exc.code == 404:
                raise ReportNotFound("No existing VirusTotal IP report was found.") from None
            raise ValueError(f"VirusTotal HTTP error {exc.code}") from None
        except URLError as exc:
            raise ValueError(f"VirusTotal network/TLS error: {exc.reason}") from None
        data = payload.get("data", {})
        if str(ipaddress.ip_address(data.get("id", ""))) != ip:
            raise ValueError("VirusTotal returned a different IP")
        attrs = data.get("attributes") or {}
        stats = attrs.get("last_analysis_stats") or {}
        date = attrs.get("last_analysis_date")
        analyzed = datetime.fromtimestamp(date, timezone.utc).isoformat(timespec="seconds") if date else ""
        return {"VT Status": "Success" if stats else "No analysis data",
                "VT Malicious": stats.get("malicious", ""), "VT Suspicious": stats.get("suspicious", ""),
                "VT Harmless": stats.get("harmless", ""), "VT Undetected": stats.get("undetected", ""),
                "VT Timeout": stats.get("timeout", ""), "VT Reputation": attrs.get("reputation", ""),
                "VT Last Analysis UTC": analyzed, "VT Report URL": "https://www.virustotal.com/gui/ip-address/" + ip,
                "VT Error": ""}


def safe_cell(value):
    """Prevent spreadsheet formula execution from provider text or source names."""
    if value is None:
        return ""
    if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def export_csv(filename, rows):
    target = Path(filename)
    fd, temporary = tempfile.mkstemp(prefix=".geolocator-", suffix=".csv", dir=target.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=FIELDS)
            writer.writeheader()
            for row in rows:
                writer.writerow({key: safe_cell(row.get(key, "")) for key in FIELDS})
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)
